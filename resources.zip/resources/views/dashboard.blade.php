@extends('layouts.app')

@section('content')   
@include('backend.includes.page-header', ['title' => 'Dashboard'])    
<div class="app-content">
    <div class="container-fluid">
        <div class="row">            
            <div class="col-lg-3 col-6">
                <div class="small-box text-bg-success">
                    <div class="inner">
                    <h3>{{ $totalCustomers }}</h3>
                    <p>Total Customers</p>
                    </div>
                    <svg
                    class="small-box-icon"
                    fill="currentColor"
                    viewBox="0 0 24 24"
                    xmlns="http://www.w3.org/2000/svg"
                    aria-hidden="true"
                    >
                    <path
                        d="M6.25 6.375a4.125 4.125 0 118.25 0 4.125 4.125 0 01-8.25 0zM3.25 19.125a7.125 7.125 0 0114.25 0v.003l-.001.119a.75.75 0 01-.363.63 13.067 13.067 0 01-6.761 1.873c-2.472 0-4.786-.684-6.76-1.873a.75.75 0 01-.364-.63l-.001-.122zM19.75 7.5a.75.75 0 00-1.5 0v2.25H16a.75.75 0 000 1.5h2.25v2.25a.75.75 0 001.5 0v-2.25H22a.75.75 0 000-1.5h-2.25V7.5z"
                    ></path>
                    </svg>
                </div>
            </div>
            <div class="col-lg-3 col-6">
                <div class="small-box text-bg-primary">
                    <div class="inner">
                    <h3>{{ $totalOrders }}</h3>
                    <p>Total Orders</p>
                    </div>
                    <svg
                    class="small-box-icon"
                    fill="currentColor"
                    viewBox="0 0 24 24"
                    xmlns="http://www.w3.org/2000/svg"
                    aria-hidden="true"
                    >
                    <path
                        d="M2.25 2.25a.75.75 0 000 1.5h1.386c.17 0 .318.114.362.278l2.558 9.592a3.752 3.752 0 00-2.806 3.63c0 .414.336.75.75.75h15.75a.75.75 0 000-1.5H5.378A2.25 2.25 0 017.5 15h11.218a.75.75 0 00.674-.421 60.358 60.358 0 002.96-7.228.75.75 0 00-.525-.965A60.864 60.864 0 005.68 4.509l-.232-.867A1.875 1.875 0 003.636 2.25H2.25zM3.75 20.25a1.5 1.5 0 113 0 1.5 1.5 0 01-3 0zM16.5 20.25a1.5 1.5 0 113 0 1.5 1.5 0 01-3 0z"
                    ></path>
                    </svg>
                </div>
            </div>
            <div class="col-lg-3 col-6">
                <div class="small-box text-bg-warning">
                    <div class="inner">
                    <h3>{{ $totalDelivered }}</h3>
                    <p>Total Delivered</p>
                    </div>
                    
                    <svg
                    class="small-box-icon"
                    fill="currentColor"
                    viewBox="0 0 24 24"
                    xmlns="http://www.w3.org/2000/svg"
                    aria-hidden="true"
                    >
                    <path
                        d="M18.375 2.25c-1.035 0-1.875.84-1.875 1.875v15.75c0 1.035.84 1.875 1.875 1.875h.75c1.035 0 1.875-.84 1.875-1.875V4.125c0-1.036-.84-1.875-1.875-1.875h-.75zM9.75 8.625c0-1.036.84-1.875 1.875-1.875h.75c1.036 0 1.875.84 1.875 1.875v11.25c0 1.035-.84 1.875-1.875 1.875h-.75a1.875 1.875 0 01-1.875-1.875V8.625zM3 13.125c0-1.036.84-1.875 1.875-1.875h.75c1.036 0 1.875.84 1.875 1.875v6.75c0 1.035-.84 1.875-1.875 1.875h-.75A1.875 1.875 0 013 19.875v-6.75z"
                    ></path>
                    </svg>
                </div>
            </div>
            <div class="col-lg-3 col-6">
                <div class="small-box text-bg-warning">
                    <div class="inner">
                    <h3>{{ $totalProducts }}</h3>
                    <p>Total Products</p>
                    </div>
                    
                    <svg
                    class="small-box-icon"
                    fill="currentColor"
                    viewBox="0 0 24 24"
                    xmlns="http://www.w3.org/2000/svg"
                    aria-hidden="true"
                    >
                    <path
                        d="M18.375 2.25c-1.035 0-1.875.84-1.875 1.875v15.75c0 1.035.84 1.875 1.875 1.875h.75c1.035 0 1.875-.84 1.875-1.875V4.125c0-1.036-.84-1.875-1.875-1.875h-.75zM9.75 8.625c0-1.036.84-1.875 1.875-1.875h.75c1.036 0 1.875.84 1.875 1.875v11.25c0 1.035-.84 1.875-1.875 1.875h-.75a1.875 1.875 0 01-1.875-1.875V8.625zM3 13.125c0-1.036.84-1.875 1.875-1.875h.75c1.036 0 1.875.84 1.875 1.875v6.75c0 1.035-.84 1.875-1.875 1.875h-.75A1.875 1.875 0 013 19.875v-6.75z"
                    ></path>
                    </svg>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="card mb-4">
                  <div class="card-header">
                    <h3 class="card-title">Latest Orders</h3>
                  </div>
                  <!-- /.card-header -->
                  <div class="card-body p-0">
                    <table class="table table-bordered">
                      <thead>
                        <tr>
                          <th style="width: 10px">#</th>
                          <th>Customer</th>
                          <th>Quantity</th>
                          <th>Total</th>
                          <th>Status</th>
                          <td>Created at</td>
                          <th style="width: 40px">Action</th>
                        </tr>
                      </thead>
                      <tbody>
                        @foreach($orders as  $order)
                          <tr class="align-middle">
                            <td>{{ $order->order_code }}</td>
                            <td>
                              @if($order->customer_id)
                                  {{ $order->customer->first_name ?? '' }} {{ $order->customer->last_name ?? '' }}
                              @else
                                  Guest
                              @endif
                            </td>
                            <td>{{ $order->items->sum('quantity') }}</td>
                            <td>{{ $order->total }} ৳</td>
                            <td>
                              @if(strtolower($order->status) === 'pending')
                                  <span class="badge text-bg-primary">{{ ucfirst($order->status) }}</span>
                              @elseif(strtolower($order->status) === 'processing')
                                  <span class="badge text-bg-warning">{{ ucfirst($order->status) }}</span>
                              @elseif(strtolower($order->status) === 'rejected')
                                  <span class="badge text-bg-danger">{{ ucfirst($order->status) }}</span>
                              @elseif(strtolower($order->status) === 'delivered')
                                  <span class="badge text-bg-success">{{ ucfirst($order->status) }}</span>
                              @else
                                  <span class="badge text-bg-secondary">{{ ucfirst($order->status) }}</span>
                              @endif
                            </td>
                            <td>{{ $order->created_at }}</td>
                            <td>
                              <a href="{{ route('admin.order_details', $order->order_code) }}" class="btn btn-sm btn-outline-info me-1"><i class="bi bi-eye"></i></a>
                            </td>
                          </tr>
                        @endforeach
                      </tbody>
                    </table>
                  </div>
                  <!-- /.card-body -->
                <div class="card-footer clearfix">
                  <div class="d-none flex-sm-fill d-sm-flex align-items-sm-center justify-content-sm-between">
                    <div>
                      <p class="small text-muted">
                        <a href="{{ route('admin.all_order') }}">More orders</a>
                      </p>
                    </div>
                  </div>  
                </div>
                </div>
                <!-- /.card -->
              </div>
            </div>
        </div>
    </div>
</div>            
@endsection    